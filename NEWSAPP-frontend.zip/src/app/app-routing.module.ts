import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { NewsSearchComponent } from './components/news-search/news-search.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { WishlistComponent } from './components/wishlist/wishlist.component';


const routes: Routes = [
  {path:'', component:LoginComponent},{path:'reg', component:RegistrationComponent},
  {path:'', redirectTo:'products',pathMatch:'full'},
  {path:'search', component:NewsSearchComponent},
  {path:'wishlist', component:WishlistComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
