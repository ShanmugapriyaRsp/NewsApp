import { TestBed } from '@angular/core/testing';
import { ValidateloginService } from './validatelogin.service';

describe('ValidateloginService', () => {
  let service: ValidateloginService;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [ValidateloginService] });
    service = TestBed.inject(ValidateloginService);
  });

  it('can load instance', () => {
    expect(service).toBeTruthy();
  });
});
