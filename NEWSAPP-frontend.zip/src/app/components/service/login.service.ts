import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { LoginRequest } from '../models/LoginRequest';
import { LoginResponse } from '../models/LoginResponse';
import { Users } from '../models/User';
import { NewsArticle } from '../models/NewsArticle';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  token : string  = '' 
  topic : string = '';  

  constructor(private http: HttpClient) {
   }

  api = 'https://newsapi.org/v2/top-headlines?country=us&apiKey=1c5e2237fcd342bf86e1cc62c9d23654';
  NEWS_PROVIDER_URL : string = 'http://localhost:8082/api/v1.0';
  WISHLIST_URL : string = 'http://localhost:8083/api/v1.0';

  testToken : string = 'Bearer '

  setTopic(topic: string) {
    this.topic = topic;
  }

  getTopic() {
    return this.topic;
  }
  getLoginStatus(){
    if(sessionStorage.getItem('loginStatus') == 'false'){
      return true;
    }
    else{
      return false;
    }
  }

  doReg(users: Users) {
    return this.http.post("http://localhost:8081/api/v1.0/user/register", users);
  }
  // doLogin(credentials: object): Observable<object> {
  //   return this.http.post("http://localhost:8080/user/login", credentials);
  // }
  doLogin(loginRequest : LoginRequest) : Observable<LoginResponse>{
    return this.http.post<LoginResponse>("http://localhost:8092/api/v1.0/auth/login",loginRequest);
  }

  

  getNewsArticles(topic : string) : Observable<NewsArticle[]>{
    return this.http.get<NewsArticle[]>(this.NEWS_PROVIDER_URL+"/news/search/"+topic, { headers: { Authorization: 'Bearer ' + sessionStorage.getItem('token') } });
    //  return this.http.get<NewsArticle[]>('http://localhost:3000/news');//for testing
  }
 
  addArticleToWishList(article : NewsArticle) : Observable<NewsArticle[]> {
    // this.token = this.token + sessionStorage.getItem('token');
    console.log('Bearer ' + sessionStorage.getItem('token'))
    return this.http.post<NewsArticle[]>(this.WISHLIST_URL+"/wishlist/add", article , { headers: { Authorization: 'Bearer ' + sessionStorage.getItem('token') } })
  }

  getArticlesWishListed(): Observable<NewsArticle[]>{
    console.log('Bearer ' + sessionStorage.getItem('token'))
    return this.http.get<NewsArticle[]>(this.WISHLIST_URL+"/wishlist/get" , { headers: { Authorization: 'Bearer ' + sessionStorage.getItem('token') } });
    // return this.httpClient.get<NewsArticle[]>('http://localhost:3000/news');//for testing
  }

  removeFromWishList(newsArticle: NewsArticle) : Observable<string>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + sessionStorage.getItem('token')
      }),
      body: newsArticle 
    };
    return this.http.delete<string>(this.WISHLIST_URL+"/wishlist/remove" , httpOptions)
  }

}
