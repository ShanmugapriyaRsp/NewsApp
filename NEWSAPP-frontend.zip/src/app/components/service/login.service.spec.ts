import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { LoginRequest } from '../models/LoginRequest';
import { Users } from '../models/User';
import { NewsArticle } from '../models/NewsArticle';
import { LoginService } from './login.service';

describe('LoginService', () => {
  let service: LoginService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [LoginService]
    });
    service = TestBed.inject(LoginService);
  });

  it('can load instance', () => {
    expect(service).toBeTruthy();
  });

  it(`api has default value`, () => {
    expect(service.api).toEqual(
      `https://newsapi.org/v2/top-headlines?country=us&apiKey=1c5e2237fcd342bf86e1cc62c9d23654`
    );
  });

  it(`NEWS_PROVIDER_URL has default value`, () => {
    expect(service.NEWS_PROVIDER_URL).toEqual(`http://localhost:8082/api/v1.0`);
  });

  it(`WISHLIST_URL has default value`, () => {
    expect(service.WISHLIST_URL).toEqual(`http://localhost:8083/api/v1.0`);
  });

  it(`testToken has default value`, () => {
    expect(service.testToken).toEqual(`Bearer `);
  });

  describe('doReg', () => {
    it('makes expected calls', () => {
      const httpTestingController = TestBed.inject(HttpTestingController);
      const usersStub: Users = <any>{};
      service.doReg(usersStub).subscribe(res => {
        expect(res).toEqual(usersStub);
      });
      const req = httpTestingController.expectOne(
        'http://localhost:8081/api/v1.0/user/register'
      );
      expect(req.request.method).toEqual('POST');
      req.flush(usersStub);
      httpTestingController.verify();
    });
  });

  describe('doLogin', () => {
    it('makes expected calls', () => {
      const httpTestingController = TestBed.inject(HttpTestingController);
      const loginRequestStub: LoginRequest = <any>{};
      service.doLogin(loginRequestStub).subscribe(res => {
        expect(res).toEqual(loginRequestStub);
      });
      const req = httpTestingController.expectOne(
        'http://localhost:8081/api/v1.0/user/register'
      );
      expect(req.request.method).toEqual('POST');
      req.flush(loginRequestStub);
      httpTestingController.verify();
    });
  });

  describe('addArticleToWishList', () => {
    it('makes expected calls', () => {
      const httpTestingController = TestBed.inject(HttpTestingController);
      const newsArticleStub: NewsArticle = <any>{};
      service.addArticleToWishList(newsArticleStub).subscribe(res => {
        expect(res).toEqual(newsArticleStub);
      });
      const req = httpTestingController.expectOne(
        'http://localhost:8081/api/v1.0/user/register'
      );
      expect(req.request.method).toEqual('POST');
      req.flush(newsArticleStub);
      httpTestingController.verify();
    });
  });

  describe('removeFromWishList', () => {
    it('makes expected calls', () => {
      const httpTestingController = TestBed.inject(HttpTestingController);
      const newsArticleStub: NewsArticle = <any>{};
      service.removeFromWishList(newsArticleStub).subscribe(res => {
        expect(res).toEqual(newsArticleStub);
      });
      const req = httpTestingController.expectOne('HTTP_ROUTE_GOES_HERE');
      expect(req.request.method).toEqual('DELETE');
      req.flush(newsArticleStub);
      httpTestingController.verify();
    });
  });

  describe('getArticlesWishListed', () => {
    it('makes expected calls', () => {
      const httpTestingController = TestBed.inject(HttpTestingController);
      service.getArticlesWishListed().subscribe(res => {
        expect(res).toEqual([]);
      });
      const req = httpTestingController.expectOne('HTTP_ROUTE_GOES_HERE');
      expect(req.request.method).toEqual('GET');
      req.flush([]);
      httpTestingController.verify();
    });
  });
});
