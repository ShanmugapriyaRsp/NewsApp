import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../service/login.service';
import { NewsArticle } from '../models/NewsArticle';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent {
  articlesWishListed : NewsArticle[] = []

  topic : string = '';
  //articlesWishListed : NewsArticle[] = []
  errorMessage : string = ''

  constructor(private newsapi : LoginService, private router : Router){
    newsapi.getArticlesWishListed().subscribe(
      (res)=>{
        this.articlesWishListed=res
        console.log(this.articlesWishListed)
        this.errorMessage = ''
      },
      (error)=>{
        this.errorMessage = 'no articles wishlisted'
        this.articlesWishListed = []
        console.log("no articles wishlisted")
      }
    )
  }
  removeFromWishList(newsArticle : NewsArticle){
    this.newsapi.removeFromWishList(newsArticle).subscribe(
      (res)=>{
        console.log("remove article success -> ",res)
      },
      (err)=>{
        console.log(err.error.text)
        if(err.error.text === 'Article removed from wishlist.'){
          // window.alert('Article removed from wishlist.')
          this.articlesWishListed = this.articlesWishListed.filter(
            article => article.Title !== newsArticle.Title
          )
        }
        console.log("remove article error -> ",err.error.status)
      }
    )
  }
  home() {
    this.router.navigate(['/']);
   
  }
}

