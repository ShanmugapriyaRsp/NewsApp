import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../service/login.service';
import { NewsArticle } from '../service/news';
import { WishlistComponent } from './wishlist.component';

describe('WishlistComponent', () => {
  let component: WishlistComponent;
  let fixture: ComponentFixture<WishlistComponent>;

  beforeEach(() => {
    const routerStub = () => ({ navigate: array => ({}) });
    const loginServiceStub = () => ({
      getArticlesWishListed: () => ({ subscribe: f => f({}) }),
      removeFromWishList: newsArticle => ({ subscribe: f => f({}) })
    });
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [WishlistComponent],
      providers: [
        { provide: Router, useFactory: routerStub },
        { provide: LoginService, useFactory: loginServiceStub }
      ]
    });
    fixture = TestBed.createComponent(WishlistComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`articlesWishListed has default value`, () => {
    expect(component.articlesWishListed).toEqual([]);
  });

  describe('removeFromWishList', () => {
    it('makes expected calls', () => {
      const loginServiceStub: LoginService = fixture.debugElement.injector.get(
        LoginService
      );
      const newsArticleStub: NewsArticle = <any>{};
      spyOn(loginServiceStub, 'removeFromWishList').and.callThrough();
      component.removeFromWishList(newsArticleStub);
      expect(loginServiceStub.removeFromWishList).toHaveBeenCalled();
    });
  });

  describe('home', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      spyOn(routerStub, 'navigate').and.callThrough();
      component.home();
      expect(routerStub.navigate).toHaveBeenCalled();
    });
  });
});
