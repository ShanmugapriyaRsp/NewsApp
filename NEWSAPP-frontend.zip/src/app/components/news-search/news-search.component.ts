import { query } from '@angular/animations';
import { HttpClientModule } from '@angular/common/http';
import { Component, NgModule, OnInit } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { debounceTime, distinctUntilChanged, switchMap} from 'rxjs';
import { AppComponent } from 'src/app/app.component';
import { LoginService } from '../service/login.service';
import { NewsArticle } from '../models/NewsArticle';

@Component({
  selector: 'app-news-search',
  templateUrl: './news-search.component.html',
  styleUrls: ['./news-search.component.css']
})

export class NewsSearchComponent {
//   mArticles:Array<any>;
//   mSources:Array<any>;
// searchArticles: any;
// newsArticle: any;

//   constructor(private newsapi:LoginService){
        
//   }

  // newslistDisplay:any = [];
  // ngOnInit(): void {
    // this.newsapi.searchTopic(this.newsArticle).subscribe(data => {
    //   console.log(data);
    //   this.newslistDisplay = data.articles;
    // })
    // this.newsapi.newsSearch().subscribe((result)=>{
    //   console.log(result);
    // })
  // }
// }

topic : string =''
newsArticles : NewsArticle[]  = [];
articlesWishListed : NewsArticle[] = []
errorMessage : string = ''
messageToCheck : string  = 'Article Already Wishlisted by the User'
errorMsgToCheck : string = ''
data:any={};
constructor(private newsApi : LoginService){
  
}

ngOnInit(): void {
  
    }

getArticles(){
  this.newsApi.getNewsArticles(this.topic).subscribe(
    (res)=>{
      console.log(this.topic +" articles are requested")
      this.newsArticles = res
      this.errorMessage = ''
    },
    (err)=>{
      console.log(err.error)
      this.newsArticles = []
      this.errorMessage = 'No articles found with the given topic ' + this.topic
    }
  );
}

addArticleToWishlist(newsArticle : NewsArticle){
  // console.log(newsArticle)
  this.newsApi.addArticleToWishList(newsArticle).subscribe(
    (res)=>{
      console.log('addArticleToWishList -> ',res)
      if(res.length >= 1){
        window.alert("Article added to your whishlist")
        //window.location.reload();
      }
    },
    (error) => {
      console.log('addArticleToWishList -> ',error)
      console.log(error.error)
      this.errorMsgToCheck = error.error;
      if(this.errorMsgToCheck.includes(this.messageToCheck)){
        window.alert("This article already added to your wishlist")
      }
    }
  )
}

}