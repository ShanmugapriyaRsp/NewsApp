import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { LoginService } from '../service/login.service';
import { NewsArticle } from '../service/news';
import { FormsModule } from '@angular/forms';
import { NewsSearchComponent } from './news-search.component';

describe('NewsSearchComponent', () => {
  let component: NewsSearchComponent;
  let fixture: ComponentFixture<NewsSearchComponent>;

  beforeEach(() => {
    const loginServiceStub = () => ({
      getNewsArticles: topic => ({ subscribe: f => f({}) }),
      addArticleToWishList: newsArticle => ({ subscribe: f => f({}) })
    });
    TestBed.configureTestingModule({
      imports: [FormsModule],
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [NewsSearchComponent],
      providers: [{ provide: LoginService, useFactory: loginServiceStub }]
    });
    fixture = TestBed.createComponent(NewsSearchComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`newsArticles has default value`, () => {
    expect(component.newsArticles).toEqual([]);
  });

  it(`articlesWishListed has default value`, () => {
    expect(component.articlesWishListed).toEqual([]);
  });

  it(`messageToCheck has default value`, () => {
    expect(component.messageToCheck).toEqual(
      `Article Already Wishlisted by the User`
    );
  });

  describe('addArticleToWishlist', () => {
    it('makes expected calls', () => {
      const loginServiceStub: LoginService = fixture.debugElement.injector.get(
        LoginService
      );
      const newsArticleStub: NewsArticle = <any>{};
      spyOn(loginServiceStub, 'addArticleToWishList').and.callThrough();
      component.addArticleToWishlist(newsArticleStub);
      expect(loginServiceStub.addArticleToWishList).toHaveBeenCalled();
    });
  });

  describe('getArticles', () => {
    it('makes expected calls', () => {
      const loginServiceStub: LoginService = fixture.debugElement.injector.get(
        LoginService
      );
      spyOn(loginServiceStub, 'getNewsArticles').and.callThrough();
      component.getArticles();
      expect(loginServiceStub.getNewsArticles).toHaveBeenCalled();
    });
  });
});
