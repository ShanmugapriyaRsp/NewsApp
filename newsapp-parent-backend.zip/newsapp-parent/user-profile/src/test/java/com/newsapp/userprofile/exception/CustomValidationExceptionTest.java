package com.newsapp.userprofile.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

class CustomValidationExceptionTest {
    @Test
    void testConstructor() {
        CustomValidationException actualCustomValidationException = new CustomValidationException("An error occurred");
        assertEquals("An error occurred", actualCustomValidationException.getLocalizedMessage());
        assertEquals("An error occurred", actualCustomValidationException.getMessage());
        assertNull(actualCustomValidationException.getCause());
        assertEquals(0, actualCustomValidationException.getSuppressed().length);
    }
}
