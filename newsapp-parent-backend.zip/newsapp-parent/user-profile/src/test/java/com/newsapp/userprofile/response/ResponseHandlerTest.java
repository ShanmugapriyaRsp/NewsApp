package com.newsapp.userprofile.response;

import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ResponseHandlerTest {

    @Test
    void testGenerateResponse() {
        assertEquals(1, ((Map<String, String>) ResponseHandler.generateResponse("Not all who wander are lost")).size());
        assertEquals("Not all who wander are lost",
                ((Map<String, String>) ResponseHandler.generateResponse("Not all who wander are lost")).get("status"));
    }
}
