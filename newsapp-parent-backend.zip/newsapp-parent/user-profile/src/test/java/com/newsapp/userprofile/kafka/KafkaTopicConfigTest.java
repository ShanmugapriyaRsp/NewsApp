package com.newsapp.userprofile.kafka;

import org.apache.kafka.clients.admin.NewTopic;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.core.KafkaAdmin;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class KafkaTopicConfigTest {
    @Test
    void testKafkaAdmin() {
        KafkaAdmin actualKafkaAdminResult = (new KafkaTopicConfig()).kafkaAdmin();
        assertEquals(1, actualKafkaAdminResult.getConfigurationProperties().size());
        assertEquals(30, actualKafkaAdminResult.getOperationTimeout());
    }

    @Test
    void testTopic1() {
        NewTopic actualTopic1Result = (new KafkaTopicConfig()).topic1();
        assertEquals("userServerTopic", actualTopic1Result.name());
        assertNull(actualTopic1Result.replicasAssignments());
        assertNull(actualTopic1Result.configs());
    }
}
