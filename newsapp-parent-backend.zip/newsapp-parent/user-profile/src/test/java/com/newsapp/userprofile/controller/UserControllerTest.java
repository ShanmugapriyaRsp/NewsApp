package com.newsapp.userprofile.controller;

import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.newsapp.userprofile.model.User;
import com.newsapp.userprofile.service.UserServiceImpl;

import java.util.concurrent.CompletableFuture;

import org.apache.kafka.clients.admin.NewTopic;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ContextConfiguration(classes = {UserController.class})
@ExtendWith(SpringExtension.class)
class UserControllerTest {
    @MockBean
    private KafkaTemplate<String, Object> kafkaTemplate;

    @MockBean
    private NewTopic newTopic;

    @Autowired
    private UserController userController;

    @MockBean
    private UserServiceImpl userServiceImpl;

    @Test
    void testRegisterUser() throws Exception {
        when(kafkaTemplate.send(Mockito.<String>any(), Mockito.<Object>any())).thenReturn(new CompletableFuture<>());
        when(newTopic.name()).thenReturn("Name");

        User user = new User();
        user.setEmail("abcd@example.org");
        user.setId(1);
        user.setPassword("password");
        user.setUserName("username");
        when(userServiceImpl.registerUser(Mockito.<User>any())).thenReturn(user);

        User user2 = new User();
        user2.setEmail("abcd@example.org");
        user2.setId(1);
        user2.setPassword("password");
        user2.setUserName("username");
        String content = (new ObjectMapper()).writeValueAsString(user2);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/v1.0/user/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(userController).build().perform(requestBuilder);
        actualPerformResult.andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("{\"status\":\"User created successfully\"}"));
    }
}
