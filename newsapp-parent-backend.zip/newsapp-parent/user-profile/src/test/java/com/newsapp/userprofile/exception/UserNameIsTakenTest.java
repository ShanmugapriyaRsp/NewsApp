package com.newsapp.userprofile.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class UserNameIsTakenTest {
    @Test
    void testConstructor() {
        UserNameIsTaken actualUserNameIsTaken = new UserNameIsTaken("foo");
        assertEquals("foo", actualUserNameIsTaken.getLocalizedMessage());
        assertEquals("foo", actualUserNameIsTaken.getMessage());
        assertNull(actualUserNameIsTaken.getCause());
        assertEquals(0, actualUserNameIsTaken.getSuppressed().length);
    }
}
