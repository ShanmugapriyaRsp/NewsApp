package com.newsapp.NewsappConfigServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsappConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
